const toggleBtn = document.getElementById('toggleBtn');
const engineSelect = document.getElementById('engineSelect');
const backendSelect = document.getElementById('backendSelect');
const delayControl = document.getElementById('delayControl');
const delaySlider = document.getElementById('delaySlider');
const delayVal = document.getElementById('delayVal');
const strengthSlider = document.getElementById('strengthSlider');
const strengthVal = document.getElementById('strengthVal');
const statusBox = document.getElementById('statusBox');

let currentActive = false;
let initializedFromState = false;

const EXT_MODEL_SOURCES = {
  gtcrn: {
    localPath: 'models/gtcrn_simple.onnx',
    remoteUrl: null,
  },
  kimvocal: {
    localPath: 'models/Kim_Vocal_2.onnx',
    remoteUrl: 'https://huggingface.co/seanghay/uvr_models/resolve/main/Kim_Vocal_2.onnx',
  },
  kimvocal_fp16: {
    localPath: 'models/Kim_Vocal_2_fp16.onnx',
    remoteUrl: 'https://raw.githubusercontent.com/atiohaidar/music_remover/main/web/models/Kim_Vocal_2_fp16.onnx',
  },
  vocft: {
    localPath: 'models/UVR-MDX-NET-Voc_FT.onnx',
    remoteUrl: 'https://huggingface.co/aaatmy/uvr-mdx-net-onnx/resolve/main/UVR-MDX-NET-Voc_FT.onnx',
  },
};

for (const opt of engineSelect.options) {
  opt.dataset.baseLabel = opt.textContent;
}

async function refreshExtensionModelLabels() {
  let cache = null;
  if ('caches' in window) {
    try {
      cache = await caches.open('music-remover-onnx-v1');
    } catch (_) { }
  }
  for (const opt of engineSelect.options) {
    const src = EXT_MODEL_SOURCES[opt.value];
    if (!src) continue;
    let ready = false;
    try {
      const localResp = await fetch(chrome.runtime.getURL(src.localPath), { method: 'HEAD' });
      if (localResp.ok) ready = true;
    } catch (_) { }
    if (!ready && cache && src.remoteUrl) {
      try {
        const hit = await cache.match(src.remoteUrl);
        if (hit) ready = true;
      } catch (_) { }
    }
    opt.textContent = ready ? `${opt.dataset.baseLabel} · ✓` : opt.dataset.baseLabel;
  }
}

function updateDelayVisibility() {
  const isGtcrn = engineSelect.value === 'gtcrn';
  delayControl.style.display = isGtcrn ? 'none' : 'block';
}

function render(state, syncInputs = false) {
  currentActive = !!state.active;
  if (syncInputs || currentActive || !initializedFromState) {
    if (state.engine) engineSelect.value = state.engine;
    if (state.backendMode) backendSelect.value = state.backendMode;
    if (state.delaySec) {
      delaySlider.value = state.delaySec;
      delayVal.textContent = `${Number(state.delaySec).toFixed(1)} s`;
    }
    const pct = Math.round((state.strength ?? 1.0) * 100);
    strengthSlider.value = pct;
    strengthVal.textContent = `${pct}%`;
    initializedFromState = true;
  }

  engineSelect.disabled = currentActive;
  backendSelect.disabled = currentActive;
  delaySlider.disabled = currentActive;
  updateDelayVisibility();

  if (state.error) {
    statusBox.className = 'status error';
    statusBox.textContent = `Error: ${state.error}`;
  } else if (currentActive) {
    statusBox.className = 'status';
    const prov = state.provider ? ` [${state.provider.toUpperCase()}]` : '';
    const defaultWait = state.engine === 'gtcrn'
      ? ' · Processing...'
      : ` · Buffering ~${Number(state.delaySec || 4.5).toFixed(0)}s...`;
    let timing = state.statusText && state.statusText !== 'Active'
      ? ` · ${state.statusText}`
      : defaultWait;
    if (state.avgInferenceMs > 0) {
      timing = state.engine === 'gtcrn'
        ? ` · ${state.avgInferenceMs.toFixed(1)} ms / 16 ms`
        : ` · ${(state.avgInferenceMs / 1000).toFixed(2)} s / chunk`;
    }
    statusBox.textContent = `Active${prov}${timing}`;
  } else {
    statusBox.className = 'status';
    statusBox.textContent = 'Idle — pilih model dan klik Start.';
  }

  toggleBtn.textContent = currentActive ? 'Stop' : 'Start on This Tab';
  toggleBtn.className = currentActive ? 'stop' : 'start';
}

async function refreshStatus(syncInputs = false) {
  const resp = await chrome.runtime.sendMessage({ type: 'GET_STATUS' });
  if (resp?.ok) render(resp.state, syncInputs);
}

engineSelect.addEventListener('change', () => {
  updateDelayVisibility();
  chrome.runtime.sendMessage({ type: 'SET_CONFIG', engine: engineSelect.value }).catch(() => { });
});

backendSelect.addEventListener('change', () => {
  chrome.runtime.sendMessage({ type: 'SET_CONFIG', backendMode: backendSelect.value }).catch(() => { });
});

delaySlider.addEventListener('input', () => {
  delayVal.textContent = `${Number(delaySlider.value).toFixed(1)} s`;
  chrome.runtime.sendMessage({ type: 'SET_CONFIG', delaySec: Number(delaySlider.value) }).catch(() => { });
});

strengthSlider.addEventListener('input', async () => {
  const pct = Number(strengthSlider.value);
  strengthVal.textContent = `${pct}%`;
  await chrome.runtime.sendMessage({
    type: 'SET_STRENGTH',
    strength: pct / 100,
  });
});

toggleBtn.addEventListener('click', async () => {
  toggleBtn.disabled = true;
  if (!currentActive) {
    statusBox.className = 'status';
    statusBox.textContent = 'Menyiapkan model & memulai capture...';
  }
  try {
    if (currentActive) {
      const resp = await chrome.runtime.sendMessage({ type: 'STOP_CAPTURE' });
      if (resp?.ok) render(resp.state);
    } else {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      const engine = engineSelect.value;
      const backendMode = backendSelect.value;
      const delaySec = Number(delaySlider.value);
      const strength = Number(strengthSlider.value) / 100;

      const resp = await chrome.runtime.sendMessage({
        type: 'START_CAPTURE',
        tabId: tab.id,
        engine,
        backendMode,
        delaySec,
        strength,
      });
      if (resp?.ok) {
        render(resp.state);
        refreshExtensionModelLabels();
      } else {
        render({ active: false, engine, backendMode, delaySec, strength, error: resp?.error || 'Failed to start' });
      }
    }
  } finally {
    toggleBtn.disabled = false;
  }
});

refreshExtensionModelLabels();
refreshStatus(true);
setInterval(() => {
  if (currentActive) refreshStatus(false);
}, 1000);
